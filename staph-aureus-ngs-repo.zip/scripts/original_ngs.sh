#!/bin/bash

# Ustawienia globalne
GENOME_REF="GCA_000013425.1.fasta"
SAMPLE_IDS=("SRR30615855" "SRR30615856")
OUTPUT_DIR="results"
LOG_FILE="pipeline.log"

# Tworzenie katalogu wyników
mkdir -p $OUTPUT_DIR
touch $LOG_FILE

# Funkcja: Przygotowanie genomu referencyjnego
prepare_reference_files() {
    echo "=== Przygotowanie genomu referencyjnego ===" | tee -a $LOG_FILE
    wget -O $OUTPUT_DIR/genome.fasta "https://api.ncbi.nlm.nih.gov/datasets/v2/genome/accession/GCF_000013425.1/download?include_annotation_type=GENOME_FASTA&include_annotation_type=GENOME_GFF&include_annotation_type=RNA_FASTA&include_annotation_type=CDS_FASTA&include_annotation_type=PROT_FASTA&include_annotation_type=SEQUENCE_REPORT&hydrated=FULLY_HYDRATED"
    bwa index $OUTPUT_DIR/genome.fasta
    samtools faidx $OUTPUT_DIR/genome.fasta
    gatk CreateSequenceDictionary -R $OUTPUT_DIR/genome.fasta -O $OUTPUT_DIR/genome.dict
}

# Funkcja: Pobieranie danych
fetch_data() {
    echo "=== Pobieranie danych NGS ===" | tee -a $LOG_FILE
    for SAMPLE in "${SAMPLE_IDS[@]}"; do
        echo "Pobieranie $SAMPLE..." | tee -a $LOG_FILE
        prefetch $SAMPLE --output-directory $OUTPUT_DIR
        fasterq-dump $OUTPUT_DIR/$SAMPLE.sra --outdir $OUTPUT_DIR --threads 4
    done
}

# Funkcja: Kontrola jakości danych
quality_control() {
    echo "=== Kontrola jakości danych ===" | tee -a $LOG_FILE
    mkdir -p $OUTPUT_DIR/fastqc_reports
    for SAMPLE in "${SAMPLE_IDS[@]}"; do
        fastqc $OUTPUT_DIR/${SAMPLE}_1.fastq $OUTPUT_DIR/${SAMPLE}_2.fastq -o $OUTPUT_DIR/fastqc_reports
    done
    multiqc $OUTPUT_DIR/fastqc_reports -o $OUTPUT_DIR/fastqc_reports
}

# Funkcja: Przycinanie odczytów
trim_reads() {
    echo "=== Przycinanie odczytów ===" | tee -a $LOG_FILE
    for SAMPLE in "${SAMPLE_IDS[@]}"; do
        trimmomatic PE -threads 4 \
            $OUTPUT_DIR/${SAMPLE}_1.fastq $OUTPUT_DIR/${SAMPLE}_2.fastq \
            $OUTPUT_DIR/${SAMPLE}_1_trimmed_paired.fastq $OUTPUT_DIR/${SAMPLE}_1_trimmed_unpaired.fastq \
            $OUTPUT_DIR/${SAMPLE}_2_trimmed_paired.fastq $OUTPUT_DIR/${SAMPLE}_2_trimmed_unpaired.fastq \
            ILLUMINACLIP:adapters.fa:2:30:10 SLIDINGWINDOW:4:20 MINLEN:36
    done
}

# Funkcja: Kontrola jakości po przycinaniu
quality_control_trimmed() {
    echo "=== Kontrola jakości przyciętych danych ===" | tee -a $LOG_FILE
    mkdir -p $OUTPUT_DIR/fastqc_trimmed_reports
    for SAMPLE in "${SAMPLE_IDS[@]}"; do
        fastqc $OUTPUT_DIR/${SAMPLE}_1_trimmed_paired.fastq $OUTPUT_DIR/${SAMPLE}_2_trimmed_paired.fastq -o $OUTPUT_DIR/fastqc_trimmed_reports
    done
    multiqc $OUTPUT_DIR/fastqc_trimmed_reports -o $OUTPUT_DIR/fastqc_trimmed_reports
}

# Funkcja: Mapowanie odczytów za pomocą BWA
run_mapping() {
    echo "=== Mapowanie odczytów za pomocą BWA ===" | tee -a $LOG_FILE
    for SAMPLE in "${SAMPLE_IDS[@]}"; do
        FORWARD="$OUTPUT_DIR/${SAMPLE}_1_trimmed_paired.fastq"
        REVERSE="$OUTPUT_DIR/${SAMPLE}_2_trimmed_paired.fastq"
        ./vimbwa.sh $FORWARD $REVERSE $GENOME_REF $OUTPUT_DIR/${SAMPLE}.bam | tee -a $LOG_FILE
    done
}

# Funkcja: Generowanie statystyk mapowania
generate_mapping_stats() {
    echo "=== Generowanie statystyk mapowania ===" | tee -a $LOG_FILE
    for SAMPLE in "${SAMPLE_IDS[@]}"; do
        samtools flagstat $OUTPUT_DIR/${SAMPLE}.bam > $OUTPUT_DIR/${SAMPLE}_mapping_stats.txt
    done
}

# Funkcja: Sprawdzenie jakości mapowania
validate_mapping_quality() {
    echo "=== Sprawdzenie jakości mapowania ===" | tee -a $LOG_FILE
    for SAMPLE in "${SAMPLE_IDS[@]}"; do
        samtools index $OUTPUT_DIR/${SAMPLE}.bam
    done
    echo "Załaduj pliki BAM i genom referencyjny do IGV dla dalszej walidacji." | tee -a $LOG_FILE
}

# Funkcja: Generowanie pliku GVCF za pomocą GATK
generate_gvcf() {
    echo "=== Generowanie GVCF ===" | tee -a $LOG_FILE
    for SAMPLE in "${SAMPLE_IDS[@]}"; do
        gatk HaplotypeCaller \
            -R $GENOME_REF \
            -I $OUTPUT_DIR/${SAMPLE}.bam \
            -O $OUTPUT_DIR/${SAMPLE}.g.vcf.gz \
            -ERC GVCF
    done
}

# Funkcja: Konsolidacja i genotypowanie wariantów za pomocą GATK
combine_and_genotype() {
    echo "=== Konsolidacja i genotypowanie wariantów ===" | tee -a $LOG_FILE
    gatk CombineGVCFs \
        -R $GENOME_REF \
        $(for SAMPLE in "${SAMPLE_IDS[@]}"; do echo "--variant $OUTPUT_DIR/${SAMPLE}.g.vcf.gz"; done) \
        -O $OUTPUT_DIR/cohort.g.vcf.gz

    gatk GenotypeGVCFs \
        -R $GENOME_REF \
        -V $OUTPUT_DIR/cohort.g.vcf.gz \
        -O $OUTPUT_DIR/raw_variants.vcf
}



# Funkcja: Filtracja wariantów za pomocą vcftools
filter_vcf_with_vcftools() {
    echo "=== Filtracja wariantów za pomocą vcftools ===" | tee -a $LOG_FILE
    vcftools --vcf $OUTPUT_DIR/high_quality_variants.vcf \
        --minQ 6000 --minDP 6000 --recode --recode-INFO-all \
        --out $OUTPUT_DIR/filtered_variants_vcftools
}

# Funkcja: Detekcja polimorfizmów za pomocą GATK
detect_variants_gatk() {
    echo "=== Detekcja polimorfizmów za pomocą GATK ===" | tee -a $LOG_FILE
    for SAMPLE in "${SAMPLE_IDS[@]}"; do
        # Krok 1: HaplotypeCaller - Generowanie GVCF
        gatk HaplotypeCaller \
            -R $GENOME_REF \
            -I $OUTPUT_DIR/${SAMPLE}.bam \
            -O $OUTPUT_DIR/${SAMPLE}.g.vcf.gz \
            -ERC GVCF

        # Krok 2: CombineGVCFs - Łączenie wyników GVCF (opcjonalne, dla wielu próbek)
        gatk CombineGVCFs \
            -R $GENOME_REF \
            --variant $OUTPUT_DIR/${SAMPLE}.g.vcf.gz \
            -O $OUTPUT_DIR/cohort_${SAMPLE}.g.vcf.gz

        # Krok 3: GenotypeGVCFs - Genotypowanie wariantów
        gatk GenotypeGVCFs \
            -R $GENOME_REF \
            -V $OUTPUT_DIR/cohort_${SAMPLE}.g.vcf.gz \
            -O $OUTPUT_DIR/raw_variants_${SAMPLE}.vcf
    done
}


# Funkcja: Detekcja wariantów za pomocą bcftools
detect_variants_bcftools() {
    echo "=== Detekcja wariantów za pomocą bcftools ===" | tee -a $LOG_FILE
    for SAMPLE in "${SAMPLE_IDS[@]}"; do
        bcftools mpileup -f $GENOME_REF $OUTPUT_DIR/${SAMPLE}.bam | \
        bcftools call -mv -Oz -o $OUTPUT_DIR/${SAMPLE}_bcftools.vcf.gz
        bcftools index $OUTPUT_DIR/${SAMPLE}_bcftools.vcf.gz
    done
}

# Funkcja: Filtrowanie wariantów bcftools
filter_bcftools_variants() {
    echo "=== Filtrowanie wariantów za pomocą bcftools ===" | tee -a $LOG_FILE
    for SAMPLE in "${SAMPLE_IDS[@]}"; do
        bcftools filter -e 'QUAL<30 || DP<10' -s LOWQUAL \
            $OUTPUT_DIR/${SAMPLE}_bcftools.vcf.gz \
            -o $OUTPUT_DIR/${SAMPLE}_filtered_bcftools.vcf.gz
        bcftools index $OUTPUT_DIR/${SAMPLE}_filtered_bcftools.vcf.gz
    done
}

# Funkcja: Nadawanie uprawnień plikom w katalogu wyników
set_permissions() {
    echo "=== Nadawanie uprawnień plikom ===" | tee -a $LOG_FILE
    chmod -R 755 $OUTPUT_DIR
    echo "Uprawnienia 755 zostały nadane wszystkim plikom w katalogu $OUTPUT_DIR" | tee -a $LOG_FILE
}

# Pipeline
prepare_reference_files
fetch_data
quality_control
trim_reads
quality_control_trimmed
run_mapping
generate_mapping_stats
validate_mapping_quality
generate_gvcf
combine_and_genotype
filter_vcf_with_vcftools
detect_variants_gatk
filter_snps_and_indels
detect_variants_bcftools
filter_bcftools_variants
set_permissions

echo "=== Pipeline zakończony ===" | tee -a $LOG_FILE
