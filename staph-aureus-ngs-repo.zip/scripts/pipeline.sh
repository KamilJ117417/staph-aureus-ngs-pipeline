#!/usr/bin/env bash
set -euo pipefail

# End-to-end pipeline for Staphylococcus aureus samples:
# SRA -> FASTQ -> QC -> trimming (fastp) -> mapping (BWA) -> variant calling (bcftools)
#
# Run:
#   ./scripts/pipeline.sh
#
# Requirements: tools in environment.yml (conda/mamba recommended).

# ---------------------------
# Config (edit if needed)
# ---------------------------
SAMPLE_IDS=("SRR30615855" "SRR30615856")
REF_ACC="GCF_000013425.1"   # Staphylococcus aureus reference (NCBI RefSeq accession)
THREADS=4

# Output layout
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REF_DIR="${ROOT_DIR}/ref"
DATA_DIR="${ROOT_DIR}/data"
RES_DIR="${ROOT_DIR}/results"
LOG_DIR="${ROOT_DIR}/logs"

RAW_DIR="${DATA_DIR}/raw"
TRIM_DIR="${DATA_DIR}/trimmed"

QC_RAW_DIR="${RES_DIR}/qc_raw"
QC_TRIM_DIR="${RES_DIR}/qc_trimmed"
TRIM_REPORT_DIR="${RES_DIR}/trim"

mkdir -p "$REF_DIR" "$RAW_DIR" "$TRIM_DIR" "$RES_DIR" "$LOG_DIR" "$QC_RAW_DIR" "$QC_TRIM_DIR" "$TRIM_REPORT_DIR"

LOG_FILE="${LOG_DIR}/pipeline_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG_FILE") 2>&1

echo "=== Pipeline start: $(date) ==="
echo "[config] samples: ${SAMPLE_IDS[*]}"
echo "[config] reference accession: $REF_ACC"
echo "[config] threads: $THREADS"
echo

# ---------------------------
# 1) Download & prepare reference
# ---------------------------
REF_ZIP="${REF_DIR}/ncbi_dataset_${REF_ACC}.zip"
REF_UNZIP_DIR="${REF_DIR}/ncbi_dataset_${REF_ACC}"
REF_FASTA="${REF_DIR}/genome.fasta"

if [[ ! -f "$REF_FASTA" ]]; then
  echo "=== [1/6] Download reference (NCBI Datasets API ZIP) ==="
  if [[ ! -f "$REF_ZIP" ]]; then
    wget -O "$REF_ZIP" "https://api.ncbi.nlm.nih.gov/datasets/v2/genome/accession/${REF_ACC}/download?include_annotation_type=GENOME_FASTA&include_annotation_type=GENOME_GFF&hydrated=FULLY_HYDRATED"
  fi
  rm -rf "$REF_UNZIP_DIR"
  unzip -o "$REF_ZIP" -d "$REF_UNZIP_DIR" >/dev/null

  # Try to locate the genome fasta inside the dataset folder
  CANDIDATE_FASTA="$(find "$REF_UNZIP_DIR" -type f \( -name "*.fna" -o -name "*genomic.fna" -o -name "*.fasta" \) | head -n 1 || true)"
  if [[ -z "${CANDIDATE_FASTA}" ]]; then
    echo "ERROR: Cannot find FASTA in $REF_UNZIP_DIR"
    echo "Hint: inspect the directory and set REF_FASTA manually."
    exit 2
  fi

  cp "$CANDIDATE_FASTA" "$REF_FASTA"
  echo "[ref] FASTA saved to: $REF_FASTA"
fi

# Create indexes (map_bwa.sh will also ensure this, but do it once here)
echo "=== [2/6] Index reference ==="
bwa index "$REF_FASTA" 2>/dev/null || true
samtools faidx "$REF_FASTA" 2>/dev/null || true
gatk CreateSequenceDictionary -R "$REF_FASTA" -O "${REF_DIR}/genome.dict" >/dev/null 2>&1 || true

# ---------------------------
# 2) Fetch reads from SRA
# ---------------------------
echo "=== [3/6] Fetch SRA + FASTQ ==="
for S in "${SAMPLE_IDS[@]}"; do
  if [[ -f "${RAW_DIR}/${S}_1.fastq.gz" && -f "${RAW_DIR}/${S}_2.fastq.gz" ]]; then
    echo "[fetch] $S already present"
    continue
  fi

  echo "[fetch] prefetch $S"
  prefetch "$S" --output-directory "$RAW_DIR"

  echo "[fetch] fasterq-dump $S"
  fasterq-dump "${RAW_DIR}/${S}.sra" --split-files --threads "$THREADS" --outdir "$RAW_DIR"

  echo "[fetch] compress fastq (pigz)"
  pigz -f -p "$THREADS" "${RAW_DIR}/${S}_1.fastq" "${RAW_DIR}/${S}_2.fastq"
done

# ---------------------------
# 3) QC raw reads
# ---------------------------
echo "=== [4/6] QC raw (FastQC + MultiQC) ==="
for S in "${SAMPLE_IDS[@]}"; do
  fastqc -t "$THREADS" "${RAW_DIR}/${S}_1.fastq.gz" "${RAW_DIR}/${S}_2.fastq.gz" -o "$QC_RAW_DIR"
done
multiqc "$QC_RAW_DIR" -o "$QC_RAW_DIR" >/dev/null || true

# ---------------------------
# 4) Trimming with fastp + QC
# ---------------------------
echo "=== [5/6] Trimming (fastp) + QC trimmed ==="
for S in "${SAMPLE_IDS[@]}"; do
  R1="${RAW_DIR}/${S}_1.fastq.gz"
  R2="${RAW_DIR}/${S}_2.fastq.gz"

  OUT1="${TRIM_DIR}/${S}_1.trim.fastq.gz"
  OUT2="${TRIM_DIR}/${S}_2.trim.fastq.gz"
  JSON="${TRIM_REPORT_DIR}/${S}.fastp.json"
  HTML="${TRIM_REPORT_DIR}/${S}.fastp.html"

  if [[ ! -f "$OUT1" || ! -f "$OUT2" ]]; then
    fastp -i "$R1" -I "$R2" -o "$OUT1" -O "$OUT2" \
      -w "$THREADS" --detect_adapter_for_pe \
      --cut_front --cut_tail --cut_window_size 4 --cut_mean_quality 20 \
      --length_required 36 \
      -j "$JSON" -h "$HTML"
  fi

  fastqc -t "$THREADS" "$OUT1" "$OUT2" -o "$QC_TRIM_DIR"
done
multiqc "$QC_TRIM_DIR" -o "$QC_TRIM_DIR" >/dev/null || true

# ---------------------------
# 5) Mapping + variant calling
# ---------------------------
echo "=== [6/6] Mapping + variant calling (bcftools) ==="
for S in "${SAMPLE_IDS[@]}"; do
  R1="${TRIM_DIR}/${S}_1.trim.fastq.gz"
  R2="${TRIM_DIR}/${S}_2.trim.fastq.gz"
  BAM="${RES_DIR}/${S}.sorted.bam"

  ./scripts/map_bwa.sh "$REF_FASTA" "$R1" "$R2" "$S" "$BAM"

  # Variant calling with bcftools
  VCF="${RES_DIR}/${S}.vcf.gz"
  if [[ ! -f "$VCF" ]]; then
    bcftools mpileup -f "$REF_FASTA" "$BAM" \
      | bcftools call -mv -Oz -o "$VCF"
    bcftools index "$VCF"
  fi
done

echo
echo "=== Pipeline finished: $(date) ==="
echo "Logs: $LOG_FILE"
