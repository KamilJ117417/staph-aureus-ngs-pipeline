#!/usr/bin/env bash
set -euo pipefail

# Map paired-end reads to reference using BWA MEM, then sort + index with samtools.
#
# Usage:
#   ./scripts/map_bwa.sh ref/genome.fasta sample_R1.fastq.gz sample_R2.fastq.gz SAMPLE_ID results/SAMPLE.sorted.bam
#
# Notes:
# - Creates reference indexes if missing (bwa + samtools + gatk dict).
# - Outputs flagstat next to BAM.

if [[ $# -ne 5 ]]; then
  echo "Usage: $0 <ref.fasta> <R1.fastq[.gz]> <R2.fastq[.gz]> <SAMPLE_ID> <out.bam>"
  exit 1
fi

REF="$1"
R1="$2"
R2="$3"
SAMPLE="$4"
OUTBAM="$5"

mkdir -p "$(dirname "$OUTBAM")"

# Index reference if needed
if [[ ! -f "${REF}.bwt" ]]; then
  echo "[map_bwa] bwa index: $REF"
  bwa index "$REF"
fi
if [[ ! -f "${REF}.fai" ]]; then
  echo "[map_bwa] samtools faidx: $REF"
  samtools faidx "$REF"
fi
DICT="${REF%.*}.dict"
if [[ ! -f "$DICT" ]]; then
  # CreateSequenceDictionary requires gatk4
  echo "[map_bwa] gatk CreateSequenceDictionary: $DICT"
  gatk CreateSequenceDictionary -R "$REF" -O "$DICT" >/dev/null
fi

echo "[map_bwa] mapping $SAMPLE"
RG="@RG\tID:${SAMPLE}\tSM:${SAMPLE}\tPL:ILLUMINA\tLB:lib1\tPU:${SAMPLE}.unit1"

bwa mem -R "$RG" "$REF" "$R1" "$R2" \
  | samtools sort -o "$OUTBAM" -

samtools index "$OUTBAM"
samtools flagstat "$OUTBAM" > "${OUTBAM}.flagstat.txt"

echo "[map_bwa] done -> $OUTBAM"
