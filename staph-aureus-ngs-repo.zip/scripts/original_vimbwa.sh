#!/bin/bash

# Skrypt do mapowania odczytów z plików FASTQ do genomu referencyjnego
# Obsługuje wiele próbek

# Sprawdzenie, czy podano argumenty
if [[ $# -lt 2 ]]; then
    echo "Użycie: $0 genome_ref.fasta sample1_forward.fastq,sample1_reverse.fastq sample2_forward.fastq,sample2_reverse.fastq ..."
    exit 1
fi

# Ścieżka do genomu referencyjnego
GENOME_REF="$1"

# Usunięcie pierwszego argumentu (genome_ref)
shift

# Sprawdzenie, czy plik genomu referencyjnego istnieje
if [[ ! -f $GENOME_REF ]]; then
    echo "Plik genomu referencyjnego $GENOME_REF nie istnieje!"
    exit 1
fi

# Przetwarzanie każdej próbki
for SAMPLE_PAIR in "$@"; do
    # Rozdzielenie par plików FASTQ
    FORWARD=$(echo $SAMPLE_PAIR | cut -d',' -f1)
    REVERSE=$(echo $SAMPLE_PAIR | cut -d',' -f2)

    # Sprawdzenie, czy pliki FASTQ istnieją
    if [[ ! -f $FORWARD ]]; then
        echo "Plik $FORWARD nie istnieje!"
        continue
    fi

    if [[ ! -f $REVERSE ]]; then
        echo "Plik $REVERSE nie istnieje!"
        continue
    fi

    # Wyciąganie informacji z pliku FORWARD FASTQ
    SM=$(head -n 1 "$FORWARD" | cut -f 1 -d':' | sed 's/@//' | cut -f 1 -d'.')
    ID=$(echo "$(head -n 1 "$FORWARD" | cut -f 3 -d':').$(head -n 1 "$FORWARD" | cut -f 4 -d':')")
    PU=$(echo "${SM}.${ID}")

    # Tworzenie unikalnej nazwy wyjściowego pliku BAM
    OUTPUT_BAM=$(basename "$FORWARD" _forward.fastq).bam

    echo "Przetwarzanie próbki: Forward=${FORWARD}, Reverse=${REVERSE}"
    echo "SM=${SM}, ID=${ID}, PU=${PU}, Output=${OUTPUT_BAM}"

    # Mapowanie z użyciem BWA MEM
    bwa mem -R "@RG\tID:${ID}\tPL:ILLUMINA\tPU:${PU}\tSM:${SM}\tLB:unknown" \
        $GENOME_REF $FORWARD $REVERSE | \
        samtools view -b > $OUTPUT_BAM

    echo "Wygenerowano plik BAM: $OUTPUT_BAM"
done
