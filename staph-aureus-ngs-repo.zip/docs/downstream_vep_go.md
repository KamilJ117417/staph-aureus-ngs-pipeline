# Downstream: VEP + GO enrichment (poza pipeline)

Pipeline w tym repo generuje pliki VCF (bcftools). Kolejne kroki często robi się już „poza skryptem” – tak jak w Twoim opisie projektu:

## 1) VEP (Variant Effect Predictor)

1. Wejdź na Ensembl / VEP (bacteria).
2. Wgraj `results/<SAMPLE>.vcf.gz` (albo zdekompresowany VCF).
3. Ustaw właściwy gatunek / szczep referencyjny (zgodny z użytym RefSeq).
4. Uruchom adnotację i pobierz wynik (np. TSV).

## 2) Wyciągnięcie listy genów

Z wyniku VEP wyciągnij kolumnę z genem (np. `Gene` / `SYMBOL` / `Feature` – zależy od formatu).

## 3) GO enrichment

- Narzędzia online: Gene Ontology, g:Profiler, Enrichr itp.
- Wklej listę genów i uruchom enrichment dla BP/MF/CC.
- Zapisz wyniki + wykresy do folderu `docs/` lub `report/`.

> Tip: do repozytorium warto wrzucać *raporty i wykresy*, ale nie ogromne pliki pośrednie.
