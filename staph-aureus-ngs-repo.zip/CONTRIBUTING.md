# Contributing

Jeśli chcesz coś poprawić/rozszerzyć:
- trzymaj duże dane poza repo (`data/`, `results/` są ignorowane),
- dodawaj opis do README i aktualizuj `environment.yml`,
- staraj się, aby skrypty były idempotentne (ponowne uruchomienie nie psuje wyników).
